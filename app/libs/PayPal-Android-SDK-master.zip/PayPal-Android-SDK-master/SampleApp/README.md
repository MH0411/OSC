PayPal Android SDK Sample App
=============================

All users can build this sample app as-is.